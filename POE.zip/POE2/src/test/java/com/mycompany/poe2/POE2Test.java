/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.poe2;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.AfterClass;

import static org.junit.Assert.*;

public class POE2Test {

    @BeforeClass
    public static void setUpClass() {
        // runs once before all tests
    }

    @AfterClass
    public static void tearDownClass() {
        // runs once after all tests
    }

    @Before
    public void setUp() {
        // runs before each test
    }

    @After
    public void tearDown() {
        // runs after each test
    }

    // Username tests
    @Test
    public void testValidateUsername() {
        assertTrue(POE2.validateUsername("kyl_"));
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(POE2.validateUsername("kylong"));  // too long
        assertFalse(POE2.validateUsername("kyl"));     // too short / no underscore
    }

    // Password tests
    @Test
    public void testValidatePassword() {
        assertTrue(POE2.validatePassword("Danny@22"));
    }

    @Test
    public void testInvalidPassword() {
        assertFalse(POE2.validatePassword("password"));   // no uppercase, digit, special
        assertFalse(POE2.validatePassword("Pass1234"));   // no special char
        assertFalse(POE2.validatePassword("pass@12"));    // no uppercase
        assertFalse(POE2.validatePassword("PASS@12"));    // no lowercase
    }

    // Cellphone tests
    @Test
    public void testValidateCellphone() {
        assertTrue(POE2.validateCellphone("+27825253163"));
    }

    @Test
    public void testInvalidCellphone() {
        assertFalse(POE2.validateCellphone("0821234567"));    // missing +27
        assertFalse(POE2.validateCellphone("+27825123"));     // too short
        assertFalse(POE2.validateCellphone("+27abcdefgh"));   // letters
        assertFalse(POE2.validateCellphone("+2712345678901")); // too long
    }

    // Register tests
    @Test
    public void testRegisterUser() {
        assertTrue(POE2.registerUser("kyl_", "Danny@22", "+27825253163"));
    }

    @Test
    public void testRegisterUser_Negative() {
        assertFalse(POE2.registerUser("longusername", "Danny@22", "+27825253163")); // invalid username
        assertFalse(POE2.registerUser("kyl01", "Danny@22", "+27825253163"));        // no underscore
        assertFalse(POE2.registerUser("kyl_", "danny@22", "+27825253163"));         // no uppercase
        assertFalse(POE2.registerUser("kyl_", "Danny22", "+27825253163"));          // no special char
        assertFalse(POE2.registerUser("kyl_", "Danny@22", "0821234567"));           // invalid phone
    }

    // Login tests
    @Test
    public void testLoginUser() {
        POE2.registerUser("kyl_", "Danny@22", "+27825253163");
        assertTrue(POE2.loginUser("kyl_", "Danny@22"));
    }

    @Test
    public void testLoginUser_Negative() {
        POE2.registerUser("kyl_", "Danny@22", "+27825253163");
        assertFalse(POE2.loginUser("wronguser", "Danny@22"));
        assertFalse(POE2.loginUser("kyl_", "wrongpass"));
        assertFalse(POE2.loginUser("wronguser", "wrongpass"));
    }
}