/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe2;

/**
 *
 * @author RC_Student_Lab
 */
import javax.swing.*;
import java.awt.*;

public class POE2 {

    // Variables to store registered account
    private static String registeredUsername;
    private static String registeredPassword;

    // Username validation
    public static boolean validateUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Password validation
    public static boolean validatePassword(String password) {
        boolean hasUpper = password.matches(".*[A-Z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[!@#$%^&(),.?\":{}|<>].*");
        boolean longEnough = password.length() >= 8;
        return hasUpper && hasDigit && hasSpecial && longEnough;
    }

    // SA cellphone validation (must start with +27 and have 9 digits after)
    public static boolean validateCellphone(String phone) {
        return phone.matches("^\\+27\\d{9}$");
    }

    // Registration Logic
    public static boolean registerUser(String username, String password, String phone) {
        if (!validateUsername(username) || !validatePassword(password) || !validateCellphone(phone)) {
            return false;
        }
        registeredUsername = username;
        registeredPassword = password;
        return true;
    }

    // Login Logic
    public static boolean loginUser(String username, String password) {
        return username.equals(registeredUsername) && password.equals(registeredPassword);
    }

    // Swing UI
    public static void createUI() {
        JFrame frame = new JFrame("Account Registration & Login");
        frame.setSize(450, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(7, 2, 10, 10));

        JTextField txtUsername = new JTextField();
        JPasswordField txtPassword = new JPasswordField();
        JTextField txtCellPhone = new JTextField();

        JButton btnRegister = new JButton("Register");
        JButton btnLogin = new JButton("Login");

        frame.add(new JLabel("Username:"));
        frame.add(txtUsername);
        frame.add(new JLabel("Password:"));
        frame.add(txtPassword);
        frame.add(new JLabel("Cellphone (+27...):"));
        frame.add(txtCellPhone);
        frame.add(btnRegister);
        frame.add(btnLogin);

        // Register button action
        btnRegister.addActionListener(e -> {
            String username = txtUsername.getText();
            String password = new String(txtPassword.getPassword());
            String cellPhone = txtCellPhone.getText();

            if (registerUser(username, password, cellPhone)) {
                JOptionPane.showMessageDialog(frame, "Registration successful!");
            } else {
                JOptionPane.showMessageDialog(frame, "Registration failed! Check username, password, and phone format.");
            }
        });

        // Login button action
        btnLogin.addActionListener(e -> {
            String user = txtUsername.getText();
            String pass = new String(txtPassword.getPassword());

            if (loginUser(user, pass)) {
                JOptionPane.showMessageDialog(frame, "Welcome " + registeredUsername + "!");
            } else {
                JOptionPane.showMessageDialog(frame, "Incorrect username or password.");
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(POE2::createUI);
    }
}
